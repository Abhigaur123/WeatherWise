package com.wise.weather.weatherwise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherwiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
