package com.wise.weather.weatherwise.dao;

import com.wise.weather.weatherwise.entity.City;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.Properties;

@Repository
public class WeatherDao {
    private String url = "jdbc:mysql://localhost:3306/weatherwise";
    private String user = "root";
    private String password = "abhishek@123";

    public int saveCity(City city) throws SQLException {
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        String query = "insert into city(id, name, temperature,humidity,windSpeed,uvIndex,description)" +
                "values("+city.getId()+", '" +city.getName() + "', '" + city.getTemperature() + "', '" + city.getHumidity() + "'" +
                ", '" + city.getWindSpeed() + "', '" + city.getUvIndex() + "', '" + city.getDescription() + "' )";

        System.out.println(">>> Query >> " + query);
       statement.execute(query);
        return city.getId();
    }

    public City getCityData(String name) throws SQLException {

        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        String query = "select * from city where name = '" + name + "'";
        System.out.println(">>> Query >> " + query);
        ResultSet resultSet = statement.executeQuery(query);
        City city = new City();
        while (resultSet.next()) {
            city.setId(resultSet.getInt("id"));
            city.setName(resultSet.getString("name"));
            city.setHumidity(resultSet.getString("humidity"));
            city.setTemperature(resultSet.getString("temperature"));
            city.setDescription(resultSet.getString("description"));
            city.setUvIndex(resultSet.getString("uvIndex"));
            city.setWindSpeed(resultSet.getString("windSpeed"));
        }
        resultSet.close();
        statement.close();
        connection.close();
        return city;
    }

    public int updateCity(City city) throws SQLException {
        Connection connection = getConnection();
        Statement statement = connection.createStatement();
        String query = "update city set name = '" + city.getName()+"', " +
        "description = '" + city.getDescription()+ "', " +
                "humidity = '" + city.getHumidity()+ "', " +
                "temperature = '" + city.getTemperature()+ "', " +
                "uvIndex = '" + city.getUvIndex()+ "', " +
                "windSpeed = '" + city.getWindSpeed()+ "' " +
                "where id = " + city.getId();
        System.out.println(">>> Query >> " + query);
        return statement.executeUpdate(query);
    }

    private Connection getConnection() {
        Properties info = new Properties();
        info.put("user", user);
        info.put("password", password);
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return connection;
    }


}
