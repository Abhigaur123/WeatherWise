package com.wise.weather.weatherwise.controllers;

import com.wise.weather.weatherwise.entity.City;
import com.wise.weather.weatherwise.services.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;

@RestController
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @PostMapping("/saveCity")
    public int saveCity(@RequestBody City city) throws SQLException {
        int id= weatherService.saveCity(city);
        return id;
    }

    @GetMapping("/getCity/{name}")
    public City getCity(@PathVariable("name") String name) throws SQLException {
        City city = weatherService.getCityData(name);
        return city;
    }

    @PostMapping("/updateCity")
    public int updateCity(@RequestBody City city) throws SQLException {
        int id = weatherService.updateCity(city);
        return id;
    }


}
