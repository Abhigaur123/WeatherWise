package com.wise.weather.weatherwise.services;

import com.wise.weather.weatherwise.dao.WeatherDao;
import com.wise.weather.weatherwise.entity.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class WeatherService {

    @Autowired
    private WeatherDao weatherDao;

    public int saveCity(City city) throws SQLException {

        return weatherDao.saveCity(city);
    }

    public City getCityData(String name) throws SQLException {
        return weatherDao.getCityData(name);
    }

    public int updateCity(City city) throws SQLException {
        return weatherDao.updateCity(city);
    }
}
